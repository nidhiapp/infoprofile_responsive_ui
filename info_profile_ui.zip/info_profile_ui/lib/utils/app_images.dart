class AppImages {
  static const String leftrectangleimg = "assets/images/pannel.png";
  static const String rightrectangleimg = "assets/images/pannel2.png";
  static const String infoProfilelogo = "assets/images/logo.png";
  static const String googly = "assets/images/goggle.png";
  static const String fbimg = "assets/images/facebook.png";
  static const String linkimg = "assets/images/linkdin.png";
  static const String appleimg = "assets/images/apple.png";
  static const String runPng = "assets/images/running.png";
  static const String appLogo = "assets/images/logo_profile.png";
  static const String worldimg = "assets/images/world_connection.png";
  static const String personIcon = "assets/images/iconperson.png";
  static const String iconLink = "assets/images/iconLink.png";
  static const String playstoreimg = "assets/images/google_play.png";
  static const String googlePlay = "assets/images/googleplay.png";
  static const String appstoreimgs = "assets/images/store_image.png";
  static const String multipleprofileimg =
      "assets/images/background_multipleprofile.png";
  static const String bulbimg = "assets/images/image_bulb.png";
  static const String logoProfile = "assets/images/media.png";
  static const String rectangularlayerimg =
      "assets/images/middle_right_card.png";
  static const String downloadapppersonimg =
      "assets/images/downloadAvilable.png";
  static const String wayimg = "assets/images/way.png";
  static const String circularbg = "assets/images/circle_bg.png";
  static const String copyRight =
      "/Users/admin/Desktop/info_profile_ui/assets/images/copyright.png";
  static const String rightcircularbg = "assets/images/right_circle_bg.png";
  static const String iconVisitingCard = "assets/images/vistingcardicon.png";
  static const String iconShareMedia = 'assets/images/sharemedia.png';
  static const String iconMultipleProf = 'assets/images/personicon.png';
  static const String creativeImg = 'assets/images/Creative .png';
  static const String doblerecoverlapbg = "assets/images/doblerecoverlapbg.png";
  static const String doubleoverlapciclebg =
      "assets/images/doubleoverlapciclebg.png";
  static const String rightdotrecbg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/rightdotrec.png";
  static const String leftdotrecbg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/leftdotrec.png";
  static const String mapimg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/worldmap.png";
  static const String mapsecbg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/mapsecbg.png";
  static const String infoProfFooterLogo =
      "/Users/admin/Desktop/info_profile_ui/assets/images/info.png";
  static const String socilaMedia =
      "/Users/admin/Desktop/info_profile_ui/assets/images/social.png";
  static const String roundrec =
      "/Users/admin/Desktop/info_profile_ui/assets/images/roundrec.png";
  static const String frame1 =
      "/Users/admin/Desktop/info_profile_ui/assets/images/frame1.png";
  static const String frame2 =
      "/Users/admin/Desktop/info_profile_ui/assets/images/fram2.png";
  static const String frame3 =
      "/Users/admin/Desktop/info_profile_ui/assets/images/frame3.png";
  static const String frame4 =
      "/Users/admin/Desktop/info_profile_ui/assets/images/frame4.png";
  static const String footerimg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/footerimg.png";
  static const String dounloadAppBg =
      "/Users/admin/Desktop/info_profile_ui/assets/images/downloadourappbg.png";
}
