import 'package:flutter/material.dart';
class LoginCardCommonWidgets extends StatelessWidget {
  const LoginCardCommonWidgets({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      
    );
  }
}